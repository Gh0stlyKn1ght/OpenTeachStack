# Downloads Index for Teaching Teachers Foundations

- Core source template files for this course
- Artifact templates and sample checklists
- Any optional media, prompts, and examples
- Export pack for instructor review

## Included for Instructor Use

- Completed examples and sample artifacts
- Checklists and review forms
- Student-safe starter files